const p="/public_daz/pictures/Modalverben_A1.jpg";export{p as _};
